# extras directory

This directory contains extra tools, utilities, and classes that may be useful, but are not a core part of the library.

These extras are likely to be less rigorously tested and documented than the core library. In some cases, they may be migrated into the library after sufficient testing and polishing.